create database  db��
use da��


CREATE TABLE Teacher (
id INT( 4 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
name VARCHAR( 10 ) NOT NULL ,
Sex VARCHAR( 10 ) NOT NULL ,
Birthday DATE NOT NULL ,
email VARCHAR( 50 ) NOT NULL ,
job INT( 20 ) NOT NULL ,
department INT( 20 ) NOT NULL
) ;


CREATE TABLE schoolRoll (
id INT( 4 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
name VARCHAR( 10 ) NOT NULL ,
primarySchool VARCHAR( 50 ) NOT NULL ,
middleSchool VARCHAR( 50 ) NOT NULL ,
highSchool VARCHAR( 50 ) NOT NULL ,
ugd VARCHAR( 50 ) NOT NULL ,
gd VARCHAR( 50 ) NOT NULL ,
doctor VARCHAR( 50 ) NOT NULL
)  ;


CREATE TABLE professionalTitle (
id INT( 4 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
name VARCHAR( 10 ) NOT NULL ,
number INT( 4 ) NOT NULL
) ;


CREATE TABLE department (
id INT( 4 ) NOT NULL AUTO_INCREMENT PRIMARY KEY ,
name VARCHAR( 10 ) NOT NULL ,
number INT( 4 ) NOT NULL
)  ;

CREATE TABLE rewardPunishment (
id INT( 4 ) NOT NULL ,
name VARCHAR( 10 ) NOT NULL ,
reward TEXT NOT NULL ,
punishment TEXT NOT NULL ,
date DATE NOT NULL
)  ;
